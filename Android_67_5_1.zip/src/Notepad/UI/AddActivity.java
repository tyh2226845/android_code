package Notepad.UI;

import java.util.Date;

import Notepad.DAO.ArticleDAO;
import Notepad.DAO.SQLiteHelper;
import Notepad.Entites.Article;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends BaseActivity {
	EditText txtTitle;
	EditText txtContent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add);

		txtTitle = (EditText) findViewById(R.id.txtTitle);
		txtContent = (EditText) findViewById(R.id.txtContent);
		Button btnSave = (Button) findViewById(R.id.btnSave);
		btnSave.setOnClickListener(new Button.OnClickListener() {

			@Override
			public void onClick(View v) {
				btnSave_click(v);
			}
		});
	}

	public void btnSave_click(View view) {

		// Ҫ���ӵ����ݿ��е�ʵ��
		Article article = new Article();
		article.setName(txtTitle.getText() + "");
		article.setContent(txtContent.getText() + "");
		article.setDate(new Date());

		// ִ�����Ӷ���
		SQLiteHelper sqLiteHelper = new SQLiteHelper(getApplicationContext());
		SQLiteDatabase db = sqLiteHelper.getWritableDatabase();

		ArticleDAO articleDao = new ArticleDAO();
		articleDao.AddArticle(db, article);

		Toast.makeText(getApplicationContext(), "�������", Toast.LENGTH_LONG)
				.show();
	}
}
