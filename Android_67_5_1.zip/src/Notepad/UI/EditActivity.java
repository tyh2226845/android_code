package Notepad.UI;

import java.util.Date;

import Notepad.DAO.ArticleDAO;
import Notepad.DAO.SQLiteHelper;
import Notepad.Entites.Article;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends BaseActivity {
	EditText txtTitle;
	EditText txtContent;
	Article article;
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_add);

		this.setTitle("�ҵ��ռ� - �༭");

		int articleId = getIntent().getExtras().getInt("id");
		SQLiteHelper helper = new SQLiteHelper(this);
		SQLiteDatabase db = helper.getReadableDatabase();

		ArticleDAO articleDao = new ArticleDAO();

		article = articleDao.GetArticleById(db, articleId);

		txtTitle = (EditText) findViewById(R.id.txtTitle);
		txtContent = (EditText) findViewById(R.id.txtContent);
		Button btnSave = (Button) findViewById(R.id.btnSave);

		txtTitle.setText(article.getName());
		txtContent.setText(article.getContent());
		
		btnSave.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View v) {
				btnSave_click(v);
			}
		});
	}

	public void btnSave_click(View view) {

		article.setName(txtTitle.getText() + "");
		article.setContent(txtContent.getText() + "");
		article.setDate(new Date());

		// ִ�и��¶���
		SQLiteHelper sqLiteHelper = new SQLiteHelper(getApplicationContext());
		SQLiteDatabase db = sqLiteHelper.getWritableDatabase();

		ArticleDAO articleDao = new ArticleDAO();
		articleDao.UpdateArticle(db, article);

		Toast.makeText(getApplicationContext(), "����ɹ���", Toast.LENGTH_LONG).show();
	}
	
}
