package Notepad.DAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Notepad.Entites.Article;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ArticleDAO {

	/**
	 * ��ѯ��������
	 * 
	 * @param db
	 * @return
	 */
	public List<Article> GetAllArticles(SQLiteDatabase db) {
		List<Article> aritlces = new ArrayList<Article>();

		if (db.isOpen()) {
			try {
				Cursor cursor = db.rawQuery(
						"select id,name,content,date from articles", null);
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd hh:mm:ss");
				while (cursor.moveToNext()) {
					Article entity = new Article();
					entity.setId(cursor.getInt(0));
					entity.setName(cursor.getString(cursor
							.getColumnIndex("name")));
					entity.setContent(cursor.getString(cursor
							.getColumnIndex("content")));

					String strdate = cursor.getString(cursor
							.getColumnIndex("date"));
					try {
						entity.setDate(sdf.parse(strdate));
					} catch (ParseException e) {
						entity.setDate(new Date());
						e.printStackTrace();
					}
					aritlces.add(entity);
				}
			} finally {
				db.close();
			}
			return aritlces;
		}
		return null;
	}

	/**
	 * ��ѯ����ͨ�����
	 * 
	 * @param db
	 * @return
	 */
	public Article GetArticleById(SQLiteDatabase db, int articleId) {
		Article entity = null;
		if (db.isOpen()) {
			try {
				Cursor cursor = db.rawQuery(
						"select id,name,content,date from articles where id=?",
						new String[] { articleId + "" });
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd hh:mm:ss");
				if (cursor.moveToNext()) {
					entity = new Article();
					entity.setId(cursor.getInt(0));
					entity.setName(cursor.getString(cursor
							.getColumnIndex("name")));
					entity.setContent(cursor.getString(cursor
							.getColumnIndex("content")));

					String strdate = cursor.getString(cursor
							.getColumnIndex("date"));
					try {
						entity.setDate(sdf.parse(strdate));
					} catch (ParseException e) {
						entity.setDate(new Date());
						e.printStackTrace();
					}
				}
			} finally {
				db.close();
			}
			return entity;
		}
		return entity;
	}

	/**
	 * �����µ�����
	 * 
	 * @param entity
	 */
	public void AddArticle(SQLiteDatabase db, Article entity) {
		if (db.isOpen()) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd hh:mm:ss");
				db.execSQL(
						"insert into articles(name,content,date) values(?,?,?)",
						new Object[] { entity.getName(), entity.getContent(),
								sdf.format(entity.getDate()) });
			} finally {
				db.close();
			}
		}
	}
	
	/**
	 * ɾ������ͨ�����
	 * 
	 * @param entity
	 */
	public void DeleteArticleByKey(SQLiteDatabase db, int id) {
		if (db.isOpen()) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd hh:mm:ss");
				db.execSQL(
						"delete from articles where id=?",
						new Object[] {id});
			} finally {
				db.close();
			}
		}
	}
	
	/**
	 * ��������
	 * 
	 * @param entity
	 */
	public void UpdateArticle(SQLiteDatabase db, Article entity) {
		if (db.isOpen()) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd hh:mm:ss");
				db.execSQL(
						"update articles set name=?,content=?,date=? where id=?",
						new Object[] { entity.getName(), entity.getContent(),
								sdf.format(entity.getDate()),entity.getId()});
			} finally {
				db.close();
			}
		}
	}
	
	
	
	
}
