package Notepad.UI;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.view.Menu;
import android.view.MenuItem;

public class BaseActivity extends Activity {

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.first, menu);
		return true;
	}

	Dialog dialog;

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent intent;
		switch (item.getItemId()) {
		case R.id.article_add:
			intent = new Intent(this, AddActivity.class);
			startActivity(intent);
			this.finish();
			break;
		case R.id.article_home:
			intent = new Intent(this, FirstActivity.class);
			startActivity(intent);
			this.finish();
			break;
		case R.id.article_exit:
			if (dialog == null) {
				Builder builder = new AlertDialog.Builder(this);
				builder.setTitle("��ʾ");
				builder.setMessage("��ȷ��Ҫ�˳�������");
				builder.setIcon(R.drawable.danger_sign);
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						System.exit(0);
						dialog.dismiss();
					}
				});

				builder.setNegativeButton("ȡ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				});

				dialog = builder.create();
			}
			dialog.show();
			break;
		}
		return true;
	}

}
