package Notepad.UI;

import java.util.List;

import Notepad.DAO.ArticleDAO;
import Notepad.DAO.SQLiteHelper;
import Notepad.Entites.Article;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.text.AlteredCharSequence;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class FirstActivity extends BaseActivity {

	ListView listArticles;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_first);

		this.setTitle("�ҵ��ռǱ�");
		listArticles = (ListView) findViewById(R.id.listArticles);

		SQLiteHelper sqLiteHelper = new SQLiteHelper(this);
		SQLiteDatabase db = sqLiteHelper.getReadableDatabase();
		ArticleDAO articleDao = new ArticleDAO();

		List<Article> articles = articleDao.GetAllArticles(db);
		Log.i("Msg", articles.size() + "");
		ListViewAdapter adapter = new ListViewAdapter(articles, this);
		listArticles.setAdapter(adapter);
	}
}
